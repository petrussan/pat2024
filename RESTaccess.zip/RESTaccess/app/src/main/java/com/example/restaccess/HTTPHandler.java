package com.example.restaccess;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class HTTPHandler {
    public HTTPHandler() {

    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    public String getAccess(String url) {
        String response = null;
        URL u = null;

        try {
            u = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("GET");

            InputStream i = new BufferedInputStream(conn.getInputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(i));
            StringBuffer r = new StringBuffer();
            while ((response=in.readLine())!=null) {
                r.append(response);
            }
            response = r.toString();

//            InputStream i = new BufferedInputStream(conn.getInputStream());
//            response = new String(i.readAllBytes(), StandardCharsets.UTF_8);
            Log.d("REST01",response);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return response;
    }

    public String postAccess(String url) {
        String response = null;

        return response;
    }


}
