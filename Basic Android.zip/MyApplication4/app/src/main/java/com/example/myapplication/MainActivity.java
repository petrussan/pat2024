package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button b1,b2,b3;
    private TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        tv = findViewById(R.id.textView);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
//        b1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tv.setText("Button 1 diklik");
//            }
//        });

    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.b1) {
            Log.d("DEBUG","b1 is clicked");
            tv.setText("Button 1 diklik");
        }
        if (view.getId()==R.id.b2) {
            Log.d("DEBUG","b2 is clicked");
            tv.setText("Button 2 diklik");
        }
        if (view.getId()==R.id.b3) {
            Log.d("DEBUG","b3 is clicked");
            Intent i = new Intent(getApplicationContext(),MainActivity2.class);
            i.putExtra("login","Agus");
            startActivity(i);
        }

    }
}